import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

interface Product {
  id: string;
  materialName: string;
  quantity: number;
  unit: string;
  rate: number;
  serialNumber: string;
  productType: string;
}

@Component({
  selector: 'app-product',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './product.component.html',
  styleUrl: './product.component.scss',
  host: {
    '[attr.data-component-id]': "'product-component'"
  }
})
export class ProductComponent implements OnInit {
  productForm: FormGroup;
  products: Product[] = [];
  units = ['meters', 'pieces', 'yards', 'kilograms'];
  productTypes = ['Raw Material', 'Finished Goods', 'Work in Progress'];
  isModalOpen = false;
  editMode = false;
  storedProducts: any=[];

  constructor(
    private fb: FormBuilder,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.productForm = this.fb.group({
      materialName: ['', [Validators.required]],
      quantity: ['', [Validators.required, Validators.min(0)]],
      unit: ['', Validators.required],
      rate: ['', [Validators.required, Validators.min(0)]],
      serialNumber: ['', Validators.required],
      productType: ['', Validators.required]
    });
  }

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.storedProducts = localStorage.getItem('products');
      if (this.storedProducts && this.storedProducts.length > 3) {
        this.products = JSON.parse(this.storedProducts);
      } else {
        // Initialize with sample data if no stored products exist
        this.products = [
          {
            id: '1',
            materialName: 'Cotton Fabric',
            quantity: 100,
            unit: 'meters',
            rate: 15.50,
            serialNumber: 'CF001',
            productType: 'Raw Material'
          },
          {
            id: '2',
            materialName: 'Denim Jeans',
            quantity: 50,
            unit: 'pieces',
            rate: 45.00,
            serialNumber: 'DJ002',
            productType: 'Finished Goods'
          },
          {
            id: '3',
            materialName: 'Shirt Panels',
            quantity: 200,
            unit: 'pieces',
            rate: 8.75,
            serialNumber: 'SP003',
            productType: 'Work in Progress'
          }
        ];
        localStorage.setItem('products', JSON.stringify(this.products));
      }
    }
  }

  openModal() {
    this.isModalOpen = true;
    this.editMode = false;
    this.productForm.reset();
  }

  closeModal() {
    this.isModalOpen = false;
    this.editMode = false;
    this.productForm.reset();
  }

  onSubmit() {
    if (this.productForm.valid) {
      const newProduct: Product = {
        id: Date.now().toString(),
        ...this.productForm.value
      };
      this.products.push(newProduct);
      if (isPlatformBrowser(this.platformId)) {
        localStorage.setItem('products', JSON.stringify(this.products));
      }
      this.productForm.reset();
      this.closeModal();
    }
  }

  deleteProduct(id: string) {
    this.products = this.products.filter(product => product.id !== id);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('products', JSON.stringify(this.products));
    }
  }

  editProduct(product: Product) {
    this.editMode = true;
    this.isModalOpen = true;
    this.deleteProduct(product.id);
    this.productForm.patchValue(product);
   
  }

}
