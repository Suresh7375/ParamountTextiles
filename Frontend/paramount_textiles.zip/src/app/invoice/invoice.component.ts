import { Component, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, FormArray } from '@angular/forms';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-invoice',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss']
})
export class InvoiceComponent {
  @ViewChild('invoiceContent') invoiceContent!: ElementRef;
  
  invoiceForm: FormGroup;
  editMode = true; // Toggle between edit mode and preview mode
  
  constructor(private fb: FormBuilder) {
    this.invoiceForm = this.fb.group({
      // Company details
      companyName: ['PARAMOUNT CLOTHING'],
      companyLocation: ['SINGAPORE'],
      companyGSTN: [''],
      
      // Invoice details
      invoiceDate: [new Date()],
      invoiceNumber: ['PC-0001'],
      ourRef: ['PC-0425-PI-01'],
      yourRef: ['PO# 20250409'],
      
      // Customer details
      billTo: this.fb.group({
        name: ['M/S. ABC STORES'],
        address: ['#01-04, BLOCK 219\nPARKLANDS\nSERANGOON\nSINGAPORE'],
        pin: ['315602'],
        gstn: ['#rdrt45et5']
      }),
      
      shipTo: this.fb.group({
        name: ['Amazon'],
        address: ['#01-04, BLOCK 219\nPARKLANDS\nSERANGOON\nSINGAPORE'],
        pin: ['315602'],
        gstn: ['#er5e45']
      }),
      
      // Invoice items
      invoiceItems: this.fb.array([
        this.createInvoiceItemFormGroup(1, 'COTTON SHIRT MATERIAL', '21011190', 65, 'MTRS', 54.55),
        this.createInvoiceItemFormGroup(2, 'COTTON PANT MATERIAL', '19019090', 51, 'MTRS', 84.75),
        this.createInvoiceItemFormGroup(3, 'LINEN SHIRT MATERIAL', '19019090', 52, 'MTRS', 98.25),
        this.createInvoiceItemFormGroup(4, 'LINEN PANT MATERIAL', '09042211', 39, 'MTRS', 143.85),
        this.createInvoiceItemFormGroup(5, 'RAYON SHIRT MATERIAL', '13019013', 75, 'MTRS', 43.45),
        this.createInvoiceItemFormGroup(6, 'RAYON PANT MATERIAL', '22021010', 59, 'MTRS', 58.90)
      ]),
      
      // Bank details
      bankDetails: this.fb.group({
        accountName: ['Paramount Clothing'],
        accountNo: ['7678197857'],
        ifsCode: ['IDIB000P012'],
        bankName: ['Indian Bank, Pallavaram'],
        swiftCode: ['IDIBINBBMEP']
      })
    });
    
    // Initialize calculations for existing items
    this.updateAllItemCalculations();
  }
  
  // Getters for form controls
  get companyName() { return this.invoiceForm.get('companyName')?.value; }
  get companyLocation() { return this.invoiceForm.get('companyLocation')?.value; }
  get companyGSTN() { return this.invoiceForm.get('companyGSTN')?.value; }
  get invoiceDate() { return this.invoiceForm.get('invoiceDate')?.value; }
  get invoiceNumber() { return this.invoiceForm.get('invoiceNumber')?.value; }
  get ourRef() { return this.invoiceForm.get('ourRef')?.value; }
  get yourRef() { return this.invoiceForm.get('yourRef')?.value; }
  get billTo() { return this.invoiceForm.get('billTo')?.value; }
  get shipTo() { return this.invoiceForm.get('shipTo')?.value; }
  get bankDetails() { return this.invoiceForm.get('bankDetails')?.value; }
  
  get invoiceItemsFormArray() {
    return this.invoiceForm.get('invoiceItems') as FormArray;
  }
  
  get invoiceItems() {
    return this.invoiceItemsFormArray.value;
  }
  
  // Create a new invoice item form group
  createInvoiceItemFormGroup(slNo: number, description = '', hsn = '', qty = 0, unit = 'MTRS', rate = 0) {
    const gstRate = 7.00; // Default GST rate
    const amount = qty * rate;
    const gstAmount = amount * (gstRate / 100);
    const total = amount + gstAmount;
    
    return this.fb.group({
      slNo: [slNo],
      description: [description],
      hsn: [hsn],
      qty: [qty],
      unit: [unit],
      rate: [rate],
      amount: [amount],
      gst: [gstRate],
      gstAmount: [gstAmount],
      total: [total]
    });
  }
  
  // Add a new invoice item
  addInvoiceItem() {
    const nextSlNo = this.invoiceItemsFormArray.length + 1;
    this.invoiceItemsFormArray.push(this.createInvoiceItemFormGroup(nextSlNo));
  }
  
  // Remove an invoice item
  removeInvoiceItem(index: number) {
    this.invoiceItemsFormArray.removeAt(index);
    // Update slNo for remaining items
    this.updateSlNumbers();
  }
  
  // Update slNo for all items after removal
  updateSlNumbers() {
    const items = this.invoiceItemsFormArray.controls;
    items.forEach((item, index) => {
      item.get('slNo')?.setValue(index + 1);
    });
  }
  
  // Update calculations for a specific item
  updateItemCalculations(index: number) {
    const item = this.invoiceItemsFormArray.at(index);
    const qty = item.get('qty')?.value || 0;
    const rate = item.get('rate')?.value || 0;
    const gstRate = item.get('gst')?.value || 0;
    
    const amount = qty * rate;
    const gstAmount = amount * (gstRate / 100);
    const total = amount + gstAmount;
    
    item.get('amount')?.setValue(amount);
    item.get('gstAmount')?.setValue(gstAmount);
    item.get('total')?.setValue(total);
  }
  
  // Update calculations for all items
  updateAllItemCalculations() {
    for (let i = 0; i < this.invoiceItemsFormArray.length; i++) {
      this.updateItemCalculations(i);
    }
  }
  
  // Totals calculations
  get subTotal(): number {
    return this.invoiceItems.reduce((sum: number, item: any) => sum + item.amount, 0);
  }
  
  get gstTotal(): number {
    return this.invoiceItems.reduce((sum: number, item: any) => sum + item.gstAmount, 0);
  }
  
  get grandTotal(): number {
    return this.invoiceItems.reduce((sum: number, item: any) => sum + item.total, 0);
  }
  
  // Convert number to words
  amountInWords(): string {
    // In a real application, this would be a function to convert the grand total to words
    // For now, we'll return a placeholder
    return `Singapore Dollars ${this.numberToWords(this.grandTotal)}`;
  }
  
  // Simple number to words conversion (placeholder implementation)
  numberToWords(num: number): string {
    // This is a simplified implementation
    // In a real application, you would use a more comprehensive conversion
    return `${num.toFixed(2)} Only`;
  }
  
  // Toggle between edit and preview modes
  toggleEditMode() {
    this.editMode = !this.editMode;
  }
  
  // Generate PDF from the invoice content
  generatePDF() {
    // First switch to preview mode if in edit mode
    if (this.editMode) {
      this.editMode = false;
      // Use setTimeout to allow the DOM to update before generating PDF
      setTimeout(() => this.createPDF(), 500);
    } else {
      this.createPDF();
    }
  }
  
  // Create the actual PDF
  private createPDF() {
    const element = this.invoiceContent.nativeElement;
    const options = {
      scale: 2,
      useCORS: true,
      allowTaint: true
    };
    
    html2canvas(element, options).then((canvas) => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      const imgHeight = canvas.height * imgWidth / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;
      
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      // Add new pages if the content is longer than one page
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      pdf.save(`invoice-${this.invoiceNumber}.pdf`);
    });
  }
}