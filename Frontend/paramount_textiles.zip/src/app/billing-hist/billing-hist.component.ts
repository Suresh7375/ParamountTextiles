import { Component, OnInit  } from '@angular/core';
import { CommonModule } from '@angular/common'; // Import CommonModule
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
// Define the interface for the data structure
interface Invoice {
  invoice: string;
  date: string;
  ourRef: string;
  yourRef: string;
  billTo: AddressDetails;
  shipTo: AddressDetails;
  productDetails: ProductDetail[];
  subTotal: number;
  gstTotal: number;
  total: number;
  bankDetails: BankDetails;
}

interface AddressDetails {
  name: string;
  address: string;
  area: string;
  city: string;
  pin: string;
  gstin: string;
}

interface ProductDetail {
  slNo: number;
  description: string;
  hsnSac: string;
  qty: number;
  unit: string;
  rate: number;
  amount: number;
  gstPercent: number;
  gstAmt: number;
  total: number;
}

interface BankDetails {
  accountName: string;
  accountNo: string;
  bankName: string;
  swiftCode: string;
  ifscCode: string;
}
@Component({
  selector: 'app-billing-hist',
  standalone: true,
  imports: [CommonModule,HttpClientModule],
  templateUrl: './billing-hist.component.html',
  styleUrl: './billing-hist.component.scss'
})
export class BillingHistComponent implements OnInit{
  
  // Dummy data array
  invoices: Invoice[] = [
    {
      invoice: 'INV-1001',
      date: '2025-04-10',
      ourRef: 'OR-101',
      yourRef: 'YR-201',
      billTo: {
        name: 'John Doe',
        address: '1234 Elm St',
        area: 'Central Area',
        city: 'Some City',
        pin: '123456',
        gstin: 'GSTIN12345'
      },
      shipTo: {
        name: 'Jane Smith',
        address: '5678 Oak Ave',
        area: 'East Side',
        city: 'Another City',
        pin: '654321',
        gstin: 'GSTIN67890'
      },
      productDetails: [
        { slNo: 1, description: 'Product A', hsnSac: '1234', qty: 2, unit: 'pcs', rate: 100, amount: 200, gstPercent: 18, gstAmt: 36, total: 236 },
        { slNo: 2, description: 'Product B', hsnSac: '5678', qty: 1, unit: 'pcs', rate: 150, amount: 150, gstPercent: 18, gstAmt: 27, total: 177 }
      ],
      subTotal: 350,
      gstTotal: 63,
      total: 413,
      bankDetails: {
        accountName: 'XYZ Ltd.',
        accountNo: '1234567890',
        bankName: 'Some Bank',
        swiftCode: 'SWIFT123',
        ifscCode: 'IFSC12345'
      }
    },
    {
      invoice: 'INV-1002',
      date: '2025-04-11',
      ourRef: 'OR-102',
      yourRef: 'YR-202',
      billTo: {
        name: 'Alice Cooper',
        address: '1234 Pine St',
        area: 'North Area',
        city: 'New City',
        pin: '234567',
        gstin: 'GSTIN23456'
      },
      shipTo: {
        name: 'Bob Dylan',
        address: '8765 Maple St',
        area: 'West Side',
        city: 'Old City',
        pin: '765432',
        gstin: 'GSTIN87654'
      },
      productDetails: [
        { slNo: 1, description: 'Product C', hsnSac: '7890', qty: 3, unit: 'pcs', rate: 200, amount: 600, gstPercent: 18, gstAmt: 108, total: 708 },
        { slNo: 2, description: 'Product D', hsnSac: '3456', qty: 2, unit: 'pcs', rate: 250, amount: 500, gstPercent: 18, gstAmt: 90, total: 590 }
      ],
      subTotal: 1100,
      gstTotal: 198,
      total: 1298,
      bankDetails: {
        accountName: 'ABC Corp.',
        accountNo: '9876543210',
        bankName: 'Big Bank',
        swiftCode: 'SWIFT456',
        ifscCode: 'IFSC67890'
      }
    }
  ];

  constructor(private http: HttpClient) { }

  ngOnInit(): void {}

  // Method to handle the preview action
  previewInvoice(invoice: Invoice): void {
    console.log('Full Invoice Details:', invoice);
    this.http.post<any>('http://localhost:5000/api/billing', invoice).subscribe(
      (data) => {
        console.log('Data from the API:', data);
      },
      (error) => {
        console.error('Error:', error);
      }
    );
  }
}
