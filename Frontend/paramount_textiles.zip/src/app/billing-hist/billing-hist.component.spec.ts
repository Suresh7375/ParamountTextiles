import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingHistComponent } from './billing-hist.component';

describe('BillingHistComponent', () => {
  let component: BillingHistComponent;
  let fixture: ComponentFixture<BillingHistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BillingHistComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BillingHistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
