import { CommonModule } from '@angular/common';
import { Component, OnInit, HostListener, PLATFORM_ID, Inject } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators, ReactiveFormsModule } from '@angular/forms';
import { isPlatformBrowser } from '@angular/common';

interface Product {
  id: number;
  name: string;
  unit: string;
  rate: number;
  gstPercentage: number;
}

@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  host: {
    '[attr.data-component-id]': "'billing-component'"
  }
})
export class BillingComponent implements OnInit {
  invoiceForm: FormGroup;
  showDropdown: boolean[] = [];
  filteredProducts: any[] = [];
  products: Product[] = [
    {
      id: 1,
      name: 'Product A',
      unit: 'PCS',
      rate: 100,
      gstPercentage: 18
    },
    {
      id: 2,
      name: 'Product B',
      unit: 'KG',
      rate: 150,
      gstPercentage: 12
    },
    {
      id: 3,
      name: 'Product C',
      unit: 'MTR',
      rate: 200,
      gstPercentage: 5
    }
  ];
  subtotal: number = 0;
  gstTotal: number = 0;
  grandTotal: number = 0;

  constructor(
    private fb: FormBuilder,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.invoiceForm = this.fb.group({
      customerName: ['', Validators.required],
      customerEmail: ['', [Validators.required, Validators.email]],
      customerPhone: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      invoiceDate: [new Date().toISOString().split('T')[0], Validators.required],
      invoiceItems: this.fb.array([])
    });
  }

  get invoiceItems() {
    return this.invoiceForm.get('invoiceItems') as FormArray;
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.invoiceForm.get(fieldName);
    return field ? field.invalid && (field.dirty || field.touched) : false;
  }

  createInvoiceItem(): FormGroup {
    return this.fb.group({
      productName: ['', Validators.required],
      qty: [1, [Validators.required, Validators.min(1)]],
      unit: [''],
      rate: [0],
      amount: [0],
      gstPercentage: [0],
      gstAmount: [0],
      total: [0]
    });
  }

  addInvoiceItem() {
    const invoiceItem = this.createInvoiceItem();
    this.invoiceItems.push(invoiceItem);
    this.showDropdown.push(false);
  }

  removeInvoiceItem(index: number) {
    this.invoiceItems.removeAt(index);
    this.showDropdown.splice(index, 1);
    this.calculateSummary();
  }

  filterProducts(event: any, index: number) {
    const searchTerm = event.target.value.toLowerCase();
    this.filteredProducts = this.products.filter(product =>
      product.name.toLowerCase().includes(searchTerm)
    );
    this.showDropdown[index] = this.filteredProducts.length > 0;
  }

  selectProduct(product: any, index: number) {
    const invoiceItem = this.invoiceItems.at(index);
    invoiceItem.patchValue({
      productName: product.name,
      unit: product.unit,
      rate: product.rate,
      gstPercentage: product.gstPercentage
    });
    this.showDropdown[index] = false;
    this.onQtyChange(index);
  }

  onQtyChange(index: number) {
    const item = this.invoiceItems.at(index);
    const qty = item.get('qty')?.value || 0;
    const rate = item.get('rate')?.value || 0;
    const gstPercentage = item.get('gstPercentage')?.value || 0;

    const amount = qty * rate;
    const gstAmount = (amount * gstPercentage) / 100;
    const total = amount + gstAmount;

    item.patchValue({
      amount: amount,
      gstAmount: gstAmount,
      total: total
    });

    this.calculateSummary();
  }

  calculateSummary() {
    this.subtotal = 0;
    this.gstTotal = 0;
    this.grandTotal = 0;

    this.invoiceItems.controls.forEach(item => {
      this.subtotal += item.get('amount')?.value || 0;
      this.gstTotal += item.get('gstAmount')?.value || 0;
      this.grandTotal += item.get('total')?.value || 0;
    });
  }

  submitInvoice() {
    if (this.invoiceForm.valid) {
      console.log('Invoice submitted:', this.invoiceForm.value);
      // Add your invoice submission logic here
    } else {
      Object.keys(this.invoiceForm.controls).forEach(key => {
        const control = this.invoiceForm.get(key);
        if (control?.invalid) {
          control.markAsTouched();
        }
      });
    }
  }

  @HostListener('document:click', ['$event'])
  closeDropdowns(event: Event) {
    const target = event.target as HTMLElement;
    if (!target.closest('.product-search')) {
      this.showDropdown = this.showDropdown.map(() => false);
    }
  }

  ngOnInit() {
    this.addInvoiceItem();
    this.filteredProducts = this.products; // Initialize filtered products with all products
  }
}
