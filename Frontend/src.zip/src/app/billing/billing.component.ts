
import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { log } from 'node:console';

interface Product {
  id: string;
  materialName: string;
  quantity: number;
  unit: string;
  rate: number;
  serialNumber: string;
  productType: string;
}

interface BillItem {
  code: string;
  name: string;
  quantity: number;
  price: number;
  category: string;
}
@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule,ReactiveFormsModule,HttpClientModule],
  host: {
    '[attr.data-component-id]': "'billing-component'"
  }
})
export class BillingComponent implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  searchText: string = '';
  productList: any;
  ProductUnit: any;
  productName: any;
  productData: any;

  ngOnInit(): void {
  this.productList=localStorage.getItem('products');
    if (this.productList) {
      this.productList = JSON.parse(this.productList);
    }
console.log(this.productList);
this.productData=this.productList

    if (isPlatformBrowser(this.platformId)) {
      const storedProducts = localStorage.getItem('products');
      if (storedProducts) {
        this.products = JSON.parse(storedProducts);
        this.filteredProducts = [...this.products];
      }
    }
  }
  invoiceForm: FormGroup;
  currentDate = new Date();
  discount = 0;
  paymentType = 'CASH';
  
  billItems: BillItem[] = [
    { code: '5', name: 'BABY JEANS', quantity: 1, price: 1000, category: 'JEANS' },
    { code: '10', name: 'EMBROIDARY FROCK', quantity: 1, price: 1800, category: 'LONG FROCKS' },
    { code: '8', name: 'STYLISH CROP TOP', quantity: 1, price: 1500, category: 'CROP TOPS' },
    { code: '1003', name: 'NORMAL T-SHIRT', quantity: 2, price: 300, category: 'T-SHIRTS FOR BOYS' },
    { code: '1014', name: 'FADE JEANS', quantity: 1, price: 900, category: 'JEANS FOR BOYS' }
  ];

  constructor(
    private fb: FormBuilder,
    @Inject(PLATFORM_ID) private platformId: Object,
    private http: HttpClient
  ) {
    this.invoiceForm = this.fb.group({

      
      // Invoice items
      invoiceItems: this.fb.array([
        this.createInvoiceItemFormGroup(1, '', '','', 0, '', 0),

      ]),
      

    });
    
    // Initialize calculations for existing items
    this.updateAllItemCalculations();
  }
  

  
  get invoiceItemsFormArray() {
    return this.invoiceForm.get('invoiceItems') as FormArray;
  }
  
  get invoiceItems() {
    return this.invoiceItemsFormArray.value;
  }
  
  // Create a new invoice item form group
  filterProducts(searchText: string) {
    if (!searchText) {
      this.filteredProducts = [...this.products];
    } else {
      this.filteredProducts = this.products.filter(product =>
        product.materialName.toLowerCase().includes(searchText.toLowerCase()) ||
        product.serialNumber.toLowerCase().includes(searchText.toLowerCase())
      );
    }
  }

  selectProduct(productId: any, index: number) {
    let productIds = productId.target.value;
    console.log(productIds);
    const item = this.invoiceItemsFormArray.at(index);
    item.patchValue({ description: '' });
    const product = this.productList.find((p: any) => p.id === productIds);
    if (product) {
      const isDuplicate = this.invoiceItemsFormArray.controls.some(item => item.get('description')?.value === product.id);
      if (isDuplicate) {
        alert('Product already selected');
        const item = this.invoiceItemsFormArray.at(index);
        item.patchValue({ description: '' });
      } else {
        const item = this.invoiceItemsFormArray.at(index);
        item.patchValue({
          description: product.id,
          unit: product.unit,
          rate: product.rate,
          qty: 1,
          productName: product.materialName
        });
        this.updateItemCalculations(index);
      }
    }
  }

  onQtyChange(index: number) {
    const item = this.invoiceItemsFormArray.at(index);
    const qty = item.get('qty')?.value || 0;
    const description = item.get('description')?.value;
    
    const product = this.products.find(p => p.materialName === description);
    if (product && qty > product.quantity) {
      item.get('qty')?.setValue(product.quantity);
    }
    this.updateItemCalculations(index);
  }

  createInvoiceItemFormGroup(slNo: number, description = '',productName='', hsn = '', qty = 0, unit = 'MTRS', rate = 0) {
    const gstRate = 7.00; // Default GST rate
    const amount = qty * rate;
    const gstAmount = amount * (gstRate / 100);
    const total = amount + gstAmount;
    
    return this.fb.group({
      slNo: [slNo],
      description: [description],
      productName: [productName],
      hsn: [hsn],
      qty: [qty],
      unit: [unit],
      rate: [rate],
      amount: [amount],
      gst: [gstRate],
      gstAmount: [gstAmount],
      total: [total]
    });
  }
  
  // Add a new invoice item
  addInvoiceItem() {

    const nextSlNo = this.invoiceItemsFormArray.length + 1;
    this.invoiceItemsFormArray.push(this.createInvoiceItemFormGroup(nextSlNo));
    // this.productData=this.productList.filter((item:any)=>item.)

    console.log(this.productData);
    
  }
  
  // Remove an invoice item
  removeInvoiceItem(index: number) {
    this.invoiceItemsFormArray.removeAt(index);
    // Update slNo for remaining items
    this.updateSlNumbers();
  }
  
  // Update slNo for all items after removal
  updateSlNumbers() {
    const items = this.invoiceItemsFormArray.controls;
    items.forEach((item, index) => {
      item.get('slNo')?.setValue(index + 1);
    });
  }
  
  // Update calculations for a specific item
  updateItemCalculations(index: number) {
    const item = this.invoiceItemsFormArray.at(index);
    const qty = item.get('qty')?.value || 0;
    const description = item.get('description')?.value;
    console.log(description);
    
    const product = this.productList?.find((p: any) => p.id === description);
    console.log(product);
    
    if (product) {
      if (qty > product.quantity) {
        item.get('qty')?.setValue(product.quantity);
        item.get('qty')?.setErrors({ 'exceedsStock': true });
      } else {
        item.get('qty')?.setErrors(null);
      }
    }

    const rate = item.get('rate')?.value || 0;
    const gstRate = item.get('gst')?.value || 0;
    
    const amount = qty * rate;
    const gstAmount = amount * (gstRate / 100);
    const total = amount + gstAmount;
    
    item.get('amount')?.setValue(amount);
    item.get('gstAmount')?.setValue(gstAmount);
    item.get('total')?.setValue(total);
  }
  
  
  // Update calculations for all items
  updateAllItemCalculations() {
    for (let i = 0; i < this.invoiceItemsFormArray.length; i++) {
      this.updateItemCalculations(i);
    }
  }
  
  // Totals calculations
  get subTotal(): number {
    return this.invoiceItems.reduce((sum: number, item: any) => sum + item.amount, 0);
  }
  
  get gstTotal(): number {
    return this.invoiceItems.reduce((sum: number, item: any) => sum + item.gstAmount, 0);
  }
  
  get grandTotal(): number {
    return this.invoiceItems.reduce((sum: number, item: any) => sum + item.total, 0);
  }
  
  // Convert number to words
  amountInWords(): string {
    // In a real application, this would be a function to convert the grand total to words
    // For now, we'll return a placeholder
    return `Singapore Dollars ${this.numberToWords(this.grandTotal)}`;
  }
  
  // Simple number to words conversion (placeholder implementation)
  numberToWords(num: number): string {
    // This is a simplified implementation
    // In a real application, you would use a more comprehensive conversion
    return `${num.toFixed(2)} Only`;
  }


  preview(): void {
    console.log('Preview clicked');
  }

  genereate_Pdf(): void {
    console.log('Complete bill clicked');
  }


  addDiscount(): void {
    console.log('Add discount clicked');
  }

  increaseQuantity(index: number): void {
    this.billItems[index].quantity += 1;
    this.updateTotal(index);
  }

  decreaseQuantity(index: number): void {
    if (this.billItems[index].quantity > 1) {
      this.billItems[index].quantity -= 1;
      this.updateTotal(index);
    }
  }

  updateTotal(index: number): void {
    // Just to trigger change detection
    this.billItems = [...this.billItems];
  }

  removeItem(index: number): void {
    this.billItems.splice(index, 1);
    this.billItems = [...this.billItems];
  }

  calculateSubTotal() {
    // return this.invoiceItemsFormArray.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const items = this.invoiceItemsFormArray.controls;
    let grandTotal = 0;
    
    items.forEach((item) => {
      const value = Number(item.get('total')?.value || 0);
      grandTotal += value;
    });
    return grandTotal
  }

  calculateGrandTotal() {
    const items = this.invoiceItemsFormArray.controls;
    let grandTotal = 0;
    
    items.forEach((item) => {
      const total = Number(item.get('total')?.value || 0);
      grandTotal += total;
    });

    // Apply discount if any
    if (this.discount && this.discount > 0) {
      grandTotal = grandTotal - Number(this.discount);
    }

    // Return with 2 decimal places
    return Number(grandTotal.toFixed(2));
  }
  productCalcFuction(){
    for (let i = 0; i <  this.productList.length; i++) {
      for (let j = 0; j <  this.invoiceItemsFormArray.controls.length; j++) {
    if (this.productList[i].id==this.invoiceItemsFormArray.controls[j].value.description) {
      console.log(this.productList[i].id);
      console.log(this.invoiceItemsFormArray.controls[j].value.description);
      this.productList[i].quantity=this.productList[i].quantity-this.invoiceItemsFormArray.controls[j].value.qty
    }
      }
    }
 console.log( this.productList);
 localStorage.setItem('products', JSON.stringify(this.productList));
  }

  generatePDF() {
    const billingdet:any = localStorage.getItem('billing_details');
        console.log(billingdet)
    const maxInvoiceNumber = Math.max(
      ...JSON.parse(billingdet).map((entry: { invoice: string; }) => parseInt(entry.invoice.replace('INV-', ''), 10))
    );
    console.log(maxInvoiceNumber+1);
    let newinvnum = maxInvoiceNumber+1;
    let invoiceNumbernew = 'INV-'+newinvnum;
    // const pdfArray = {
    //   invoiceDetail: {
    //     invoice: "INV-1001",
    //     date: "2025-04-10",
    //     ourRef: "OR-101",
    //     yourRef: "YR-201"
    //   },
    //   billTo: {
    //     name: "John Doe",
    //     address: "1234 Elm St",
    //     area: "Central Area",
    //     city: "Some City",
    //     pin: "123456",
    //     gstin: "GSTIN12345"
    //   },
    //   shipTo: {
    //     name: "Jane Smith",
    //     address: "5678 Oak Ave",
    //     area: "East Side",
    //     city: "Another City",
    //     pin: "654321",
    //     gstin: "GSTIN67890"
    //   },
    //   productDetails: this.invoiceItemsFormArray.controls.map((item, index) => ({
    //     slNo: index + 1,
    //     product_id: item.get('description')?.value || '',
    //     product_name: item.get('productName')?.value || '',
    //     hsnSac: item.get('hsn')?.value || '',
    //     qty: item.get('qty')?.value || 0,
    //     unit: item.get('unit')?.value || '',
    //     rate: item.get('rate')?.value || 0,
    //     amount: item.get('amount')?.value || 0,
    //     gstPercent: item.get('gst')?.value || 0,
    //     gstAmt: item.get('gstAmount')?.value || 0,
    //     total: item.get('total')?.value || 0
    //   })),
    //   bankDetails: {
    //     accountName: "XYZ Ltd.",
    //     accountNo: "1234567890",
    //     bankName: "Some Bank",
    //     swiftCode: "SWIFT123",
    //     ifscCode: "IFSC12345"
    //   }
    // };
console.log(this.invoiceItemsFormArray.controls);


    const productDetails = this.invoiceItemsFormArray.controls.map((item, index) => {
      const qty = item.get('qty')?.value || 0;
      const rate = item.get('rate')?.value || 0;
      const amount = qty * rate;
      const gstPercent = item.get('gst')?.value || 0;
      const gstAmt = (amount * gstPercent) / 100;
      const total = amount + gstAmt;
    
      return {
        slNo: index + 1,
        description: item.get('productName')?.value || '',
        hsnSac: item.get('hsn')?.value || '',
        qty,
        unit: item.get('unit')?.value || '',
        rate,
        amount,
        gstPercent,
        gstAmt,
        total
      };
    });
    
    const subTotal = productDetails.reduce((sum, p) => sum + p.amount, 0);
    const gstTotal = productDetails.reduce((sum, p) => sum + p.gstAmt, 0);
    const total = subTotal + gstTotal;
    
    const pdfArrayRaw = {
      invoice: invoiceNumbernew,
      date: "2025-04-10",
      ourRef: "OR-101",
      yourRef: "YR-201",
      billTo: {
        name: "John Doe",
        address: "1234 Elm St",
        area: "Central Area",
        city: "Some City",
        pin: "123456",
        gstin: "GSTIN12345"
      },
      shipTo: {
        name: "Jane Smith",
        address: "5678 Oak Ave",
        area: "East Side",
        city: "Another City",
        pin: "654321",
        gstin: "GSTIN67890"
      },
      productDetails,
      subTotal,
      gstTotal,
      total,
      bankDetails: {
        accountName: "XYZ Ltd.",
        accountNo: "1234567890",
        bankName: "Some Bank",
        swiftCode: "SWIFT123",
        ifscCode: "IFSC12345"
      }
    };
    console.log(JSON.stringify(pdfArrayRaw));

    this.http.post<any>('http://localhost:5000/api/billing', pdfArrayRaw).subscribe(
      (data) => {
        console.log('Data from the API:', data);
        if(data.message==0){
          this.productCalcFuction()
          const billexistingData = JSON.parse(localStorage.getItem('billing_details') || '[]');
          const normalizedPdfArray = Array.isArray(pdfArrayRaw) ? pdfArrayRaw : [pdfArrayRaw];          
          const updatedData = [...billexistingData, ...normalizedPdfArray];
          localStorage.setItem('billing_details', JSON.stringify(updatedData));
          window.open(data.invoice_path, '_blank');
        }
        else{
          alert("Something went wrong");
        }
      },
      (error) => {
        console.error('Error:', error);
      }
    );
  }


}