import { Component, OnInit } from '@angular/core';
import { ThemeService } from '../core/services/theme.service';

@Component({
  selector: 'app-dashboard',
  template: `
    <div class="dashboard-container">
      <div class="dashboard-header">
        <h1>Textile Dashboard</h1>
      </div>

      <div class="metrics-grid">
        <div class="metric-card">
          <div class="metric-icon inventory"></div>
          <div class="metric-content">
            <h3>Inventory Status</h3>
            <div class="metric-value">12,450</div>
            <div class="metric-label">Units in Stock</div>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon production"></div>
          <div class="metric-content">
            <h3>Production Rate</h3>
            <div class="metric-value">856</div>
            <div class="metric-label">Units/Day</div>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon orders"></div>
          <div class="metric-content">
            <h3>Pending Orders</h3>
            <div class="metric-value">234</div>
            <div class="metric-label">Orders</div>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon revenue"></div>
          <div class="metric-content">
            <h3>Revenue</h3>
            <div class="metric-value">$45,678</div>
            <div class="metric-label">This Month</div>
          </div>
        </div>
      </div>

      <div class="charts-grid">
        <div class="chart-card">
          <h3>Production Trends</h3>
          <div class="chart-container">
            <!-- Chart placeholder -->
            <div class="chart-placeholder production-chart"></div>
          </div>
        </div>

        <div class="chart-card">
          <h3>Material Usage</h3>
          <div class="chart-container">
            <!-- Chart placeholder -->
            <div class="chart-placeholder material-chart"></div>
          </div>
        </div>

        <div class="chart-card wide">
          <h3>Order Timeline</h3>
          <div class="chart-container">
            <!-- Chart placeholder -->
            <div class="chart-placeholder timeline-chart"></div>
          </div>
        </div>
      </div>
    </div>
  `,
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  constructor(private themeService: ThemeService) {}

  ngOnInit(): void {}
}