import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
// Define the interface for the data structure
interface Invoice {
  invoice: string;
  date: string;
  ourRef: string;
  yourRef: string;
  billTo: AddressDetails;
  shipTo: AddressDetails;
  productDetails: ProductDetail[];
  subTotal: number;
  gstTotal: number;
  total: number;
  bankDetails: BankDetails;
}

interface AddressDetails {
  name: string;
  address: string;
  area: string;
  city: string;
  pin: string;
  gstin: string;
}

interface ProductDetail {
  slNo: number;
  description: string;
  hsnSac: string;
  qty: number;
  unit: string;
  rate: number;
  amount: number;
  gstPercent: number;
  gstAmt: number;
  total: number;
}

interface BankDetails {
  accountName: string;
  accountNo: string;
  bankName: string;
  swiftCode: string;
  ifscCode: string;
}

interface Product {
  id: string;
  materialName: string;
  quantity: number;
  unit: string;
  rate: number;
  serialNumber: string;
  productType: string;
}

@Component({
  selector: 'app-product',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './product.component.html',
  styleUrl: './product.component.scss',
  host: {
    '[attr.data-component-id]': "'product-component'"
  }
})
export class ProductComponent implements OnInit {
  productForm: FormGroup;
  products: Product[] = [];
  invoices:Invoice[] = [];
  units = ['meters', 'pieces', 'yards', 'kilograms'];
  productTypes = ['Raw Material', 'Finished Goods', 'Work in Progress'];
  isModalOpen = false;
  editMode = false;
  storedProducts: any=[];

  searchTerm: string = '';

  get filteredProducts() {
    const searchStr = this.searchTerm?.toLowerCase() || '';
    return this.products.filter(product => 
      product.materialName.toLowerCase().includes(searchStr) ||
      product.serialNumber.toLowerCase().includes(searchStr) ||
      product.productType.toLowerCase().includes(searchStr) ||
      product.unit.toLowerCase().includes(searchStr) ||
      product.quantity.toString().includes(searchStr) ||
      product.rate.toString().includes(searchStr)
    );
  }

  constructor(
    private fb: FormBuilder,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.productForm = this.fb.group({
      materialName: ['', [Validators.required]],
      quantity: ['', [Validators.required, Validators.min(0)]],
      unit: ['', Validators.required],
      rate: ['', [Validators.required, Validators.min(0)]],
      serialNumber: ['', Validators.required],
      productType: ['', Validators.required]
    });
  }

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.storedProducts = localStorage.getItem('products');
      if (this.storedProducts && this.storedProducts.length > 3) {
        this.products = JSON.parse(this.storedProducts);
      } else {
        // Initialize with sample data if no stored products exist
        this.products = [
          
          {
            id: '1',
            materialName: 'Cotton Fabric',
            quantity: 100,
            unit: 'meters',
            rate: 15.50,
            serialNumber: 'CF001',
            productType: 'Raw Material'
          },
          {
            id: '2',
            materialName: 'Denim Jeans',
            quantity: 50,
            unit: 'pieces',
            rate: 45.00,
            serialNumber: 'DJ002',
            productType: 'Finished Goods'
          },
          {
            id: '3',
            materialName: 'Shirt Panels',
            quantity: 200,
            unit: 'pieces',
            rate: 8.75,
            serialNumber: 'SP003',
            productType: 'Work in Progress'
          },
          {
            id: '4',
            materialName: 'Silk Lining',
            quantity: 75,
            unit: 'meters',
            rate: 22.30,
            serialNumber: 'SL004',
            productType: 'Raw Material'
          },
          {
            id: '5',
            materialName: 'Leather Jackets',
            quantity: 25,
            unit: 'pieces',
            rate: 120.00,
            serialNumber: 'LJ005',
            productType: 'Finished Goods'
          },
          {
            id: '6',
            materialName: 'Sleeve Components',
            quantity: 150,
            unit: 'pieces',
            rate: 5.60,
            serialNumber: 'SC006',
            productType: 'Work in Progress'
          }
        ];

        this.invoices = [
          {
            invoice: 'INV-1001',
            date: '2025-04-10',
            ourRef: 'OR-101',
            yourRef: 'YR-201',
            billTo: {
              name: 'John Doe',
              address: '1234 Elm St',
              area: 'Central Area',
              city: 'Some City',
              pin: '123456',
              gstin: 'GSTIN12345'
            },
            shipTo: {
              name: 'Jane Smith',
              address: '5678 Oak Ave',
              area: 'East Side',
              city: 'Another City',
              pin: '654321',
              gstin: 'GSTIN67890'
            },
            productDetails: [
              { slNo: 1, description: 'Product A', hsnSac: '1234', qty: 2, unit: 'pcs', rate: 100, amount: 200, gstPercent: 18, gstAmt: 36, total: 236 },
              { slNo: 2, description: 'Product B', hsnSac: '5678', qty: 1, unit: 'pcs', rate: 150, amount: 150, gstPercent: 18, gstAmt: 27, total: 177 }
            ],
            subTotal: 350,
            gstTotal: 63,
            total: 413,
            bankDetails: {
              accountName: 'XYZ Ltd.',
              accountNo: '1234567890',
              bankName: 'Some Bank',
              swiftCode: 'SWIFT123',
              ifscCode: 'IFSC12345'
            }
          },
          {
            invoice: 'INV-1002',
            date: '2025-04-11',
            ourRef: 'OR-102',
            yourRef: 'YR-202',
            billTo: {
              name: 'Alice Cooper',
              address: '1234 Pine St',
              area: 'North Area',
              city: 'New City',
              pin: '234567',
              gstin: 'GSTIN23456'
            },
            shipTo: {
              name: 'Bob Dylan',
              address: '8765 Maple St',
              area: 'West Side',
              city: 'Old City',
              pin: '765432',
              gstin: 'GSTIN87654'
            },
            productDetails: [
              { slNo: 1, description: 'Product C', hsnSac: '7890', qty: 3, unit: 'pcs', rate: 200, amount: 600, gstPercent: 18, gstAmt: 108, total: 708 },
              { slNo: 2, description: 'Product D', hsnSac: '3456', qty: 2, unit: 'pcs', rate: 250, amount: 500, gstPercent: 18, gstAmt: 90, total: 590 }
            ],
            subTotal: 1100,
            gstTotal: 198,
            total: 1298,
            bankDetails: {
              accountName: 'ABC Corp.',
              accountNo: '9876543210',
              bankName: 'Big Bank',
              swiftCode: 'SWIFT456',
              ifscCode: 'IFSC67890'
            }
          },
          {
            invoice: 'INV-1003',
            date: '2025-04-12',
            ourRef: 'OR-103',
            yourRef: 'YR-203',
            billTo: {
              name: 'Ravi Kumar',
              address: '88 Industrial Rd',
              area: 'West Park',
              city: 'Chennai',
              pin: '600042',
              gstin: 'GSTIN99001'
            },
            shipTo: {
              name: 'Nisha Rao',
              address: '11 Textile Lane',
              area: 'Market Yard',
              city: 'Hyderabad',
              pin: '500012',
              gstin: 'GSTIN99002'
            },
            productDetails: [
              { slNo: 1, description: 'Cotton Fabric', hsnSac: '5208', qty: 10, unit: 'meters', rate: 15.50, amount: 155, gstPercent: 5, gstAmt: 7.75, total: 162.75 },
              { slNo: 2, description: 'Silk Lining', hsnSac: '5007', qty: 5, unit: 'meters', rate: 22.30, amount: 111.5, gstPercent: 5, gstAmt: 5.58, total: 117.08 }
            ],
            subTotal: 266.50,
            gstTotal: 13.33,
            total: 279.83,
            bankDetails: {
              accountName: 'Tex Fab Pvt Ltd.',
              accountNo: '1122334455',
              bankName: 'Axis Bank',
              swiftCode: 'AXISINBB',
              ifscCode: 'UTIB0001234'
            }
          },
          {
            invoice: 'INV-1004',
            date: '2025-04-13',
            ourRef: 'OR-104',
            yourRef: 'YR-204',
            billTo: {
              name: 'Meera Shah',
              address: '202 Fashion Street',
              area: 'MG Road',
              city: 'Pune',
              pin: '411001',
              gstin: 'GSTIN99003'
            },
            shipTo: {
              name: 'Vikram Mehta',
              address: '44 Main Bazaar',
              area: 'North Zone',
              city: 'Ahmedabad',
              pin: '380001',
              gstin: 'GSTIN99004'
            },
            productDetails: [
              { slNo: 1, description: 'Denim Jeans', hsnSac: '6103', qty: 4, unit: 'pieces', rate: 45.00, amount: 180, gstPercent: 12, gstAmt: 21.60, total: 201.60 }
            ],
            subTotal: 180,
            gstTotal: 21.60,
            total: 201.60,
            bankDetails: {
              accountName: 'Style Wear Ltd.',
              accountNo: '5566778899',
              bankName: 'ICICI Bank',
              swiftCode: 'ICICINBBXXX',
              ifscCode: 'ICIC0005678'
            }
          },
          {
            invoice: 'INV-1005',
            date: '2025-04-14',
            ourRef: 'OR-105',
            yourRef: 'YR-205',
            billTo: {
              name: 'Anjali Verma',
              address: '90 Silk St',
              area: 'Central Market',
              city: 'Kolkata',
              pin: '700017',
              gstin: 'GSTIN99005'
            },
            shipTo: {
              name: 'Raj Singh',
              address: '15 Designer Lane',
              area: 'New Colony',
              city: 'Delhi',
              pin: '110003',
              gstin: 'GSTIN99006'
            },
            productDetails: [
              { slNo: 1, description: 'Shirt Panels', hsnSac: '6205', qty: 10, unit: 'pieces', rate: 8.75, amount: 87.5, gstPercent: 12, gstAmt: 10.50, total: 98.00 },
              { slNo: 2, description: 'Sleeve Components', hsnSac: '6206', qty: 20, unit: 'pieces', rate: 5.60, amount: 112.00, gstPercent: 12, gstAmt: 13.44, total: 125.44 }
            ],
            subTotal: 199.50,
            gstTotal: 23.94,
            total: 223.44,
            bankDetails: {
              accountName: 'Modern Apparels',
              accountNo: '3344556677',
              bankName: 'HDFC Bank',
              swiftCode: 'HDFCINBB',
              ifscCode: 'HDFC0007654'
            }
          },
          {
            invoice: 'INV-1006',
            date: '2025-04-15',
            ourRef: 'OR-106',
            yourRef: 'YR-206',
            billTo: {
              name: 'Tarun Joshi',
              address: '99 Yarn Nagar',
              area: 'South Sector',
              city: 'Surat',
              pin: '395003',
              gstin: 'GSTIN99007'
            },
            shipTo: {
              name: 'Karishma Patel',
              address: '88 Fashion Valley',
              area: 'West End',
              city: 'Vadodara',
              pin: '390001',
              gstin: 'GSTIN99008'
            },
            productDetails: [
              { slNo: 1, description: 'Leather Jackets', hsnSac: '4203', qty: 3, unit: 'pieces', rate: 120.00, amount: 360.00, gstPercent: 18, gstAmt: 64.80, total: 424.80 }
            ],
            subTotal: 360.00,
            gstTotal: 64.80,
            total: 424.80,
            bankDetails: {
              accountName: 'Urban Trends',
              accountNo: '7788990011',
              bankName: 'SBI',
              swiftCode: 'SBININBBXXX',
              ifscCode: 'SBIN0003344'
            }
          },
          {
            invoice: 'INV-1007',
            date: '2025-04-16',
            ourRef: 'OR-107',
            yourRef: 'YR-207',
            billTo: {
              name: 'Sneha Reddy',
              address: '12 Tailor Rd',
              area: 'East Market',
              city: 'Bangalore',
              pin: '560001',
              gstin: 'GSTIN99009'
            },
            shipTo: {
              name: 'Arjun Nair',
              address: '54 Fashion Hub',
              area: 'South Side',
              city: 'Coimbatore',
              pin: '641001',
              gstin: 'GSTIN99010'
            },
            productDetails: [
              { slNo: 1, description: 'Cotton Fabric', hsnSac: '5208', qty: 15, unit: 'meters', rate: 15.50, amount: 232.5, gstPercent: 5, gstAmt: 11.63, total: 244.13 },
              { slNo: 2, description: 'Shirt Panels', hsnSac: '6205', qty: 10, unit: 'pieces', rate: 8.75, amount: 87.5, gstPercent: 12, gstAmt: 10.5, total: 98.00 }
            ],
            subTotal: 320.00,
            gstTotal: 22.13,
            total: 342.13,
            bankDetails: {
              accountName: 'Cotton Works',
              accountNo: '9911223344',
              bankName: 'Yes Bank',
              swiftCode: 'YESBINBB',
              ifscCode: 'YESB0000123'
            }
          },
          {
            invoice: 'INV-1008',
            date: '2025-04-17',
            ourRef: 'OR-108',
            yourRef: 'YR-208',
            billTo: {
              name: 'Karan Bhatt',
              address: '34 Industrial Estate',
              area: 'GIDC Zone',
              city: 'Rajkot',
              pin: '360003',
              gstin: 'GSTIN99011'
            },
            shipTo: {
              name: 'Divya Singh',
              address: '67 Garment Nagar',
              area: 'Export Area',
              city: 'Indore',
              pin: '452001',
              gstin: 'GSTIN99012'
            },
            productDetails: [
              { slNo: 1, description: 'Sleeve Components', hsnSac: '6206', qty: 30, unit: 'pieces', rate: 5.60, amount: 168.00, gstPercent: 12, gstAmt: 20.16, total: 188.16 },
              { slNo: 2, description: 'Denim Jeans', hsnSac: '6103', qty: 2, unit: 'pieces', rate: 45.00, amount: 90.00, gstPercent: 12, gstAmt: 10.80, total: 100.80 }
            ],
            subTotal: 258.00,
            gstTotal: 30.96,
            total: 288.96,
            bankDetails: {
              accountName: 'Prime Tailors',
              accountNo: '4433221100',
              bankName: 'Kotak Mahindra Bank',
              swiftCode: 'KKBKINBB',
              ifscCode: 'KKBK0001234'
            }
          }
        ];
        
        
        // localStorage.setItem('products', JSON.stringify(this.products));
        const existing = localStorage.getItem('products');
        console.log(existing)
        if (existing) {
          localStorage.removeItem('products');
          localStorage.setItem('billing_details', JSON.stringify(this.products));
        }
        localStorage.setItem('billing_details', JSON.stringify(this.products));

        const existing1 = localStorage.getItem('billing_details');
        console.log(existing1)
        if (existing) {
          localStorage.removeItem('billing_details');
          localStorage.setItem('billing_details', JSON.stringify(this.invoices));
        }
        localStorage.setItem('billing_details', JSON.stringify(this.invoices));

      }
    }
  }

  openModal() {
    this.isModalOpen = true;
    this.editMode = false;
    this.productForm.reset();
  }

  closeModal() {
    this.isModalOpen = false;
    this.editMode = false;
    this.productForm.reset();
  }

  onSubmit() {
    if (this.productForm.valid) {
      const newProduct: Product = {
        id: Date.now().toString(),
        ...this.productForm.value
      };
      this.products.push(newProduct);
      if (isPlatformBrowser(this.platformId)) {
        localStorage.setItem('products', JSON.stringify(this.products));
      }
      this.productForm.reset();
      this.closeModal();
    }
  }

  deleteProduct(id: string) {
    this.products = this.products.filter(product => product.id !== id);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('products', JSON.stringify(this.products));
    }
  }

  editProduct(product: Product) {
    this.editMode = true;
    this.isModalOpen = true;
    this.deleteProduct(product.id);
    this.productForm.patchValue(product);
   
  }

}
